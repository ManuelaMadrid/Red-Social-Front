import { useEffect, useState } from "react"
import Navbar from "./Components/Navbar"
import LeftSidebar from "./Components/LeftSidebar"
import RightSidebar from "./Components/RightSidebar"
import Footer from "./Components/Footer"
import { Inicio, Noticias, Perfil, Cuenta, Mensajes } from "./Components/Pages"
import { Login, Registro } from "./Components/Auth"
import { StoreProvider, useStore } from "./store"

// Rutas de la app (se navega con enlaces tipo href="#/ruta")
const routes = {
  "/": Inicio,
  "/noticias": Noticias,
  "/perfil": Perfil,
  "/cuenta": Cuenta,
  "/mensajes": Mensajes,
  "/login": Login,
  "/registro": Registro,
}

// Páginas que requieren haber iniciado sesión
const privateRoutes = ["/perfil", "/cuenta", "/mensajes"]

function useHashRoute() {
  const read = () => window.location.hash.replace(/^#/, "") || "/"
  const [route, setRoute] = useState(read)
  useEffect(() => {
    const onChange = () => {
      setRoute(read())
      window.scrollTo(0, 0)
    }
    window.addEventListener("hashchange", onChange)
    return () => window.removeEventListener("hashchange", onChange)
  }, [])
  return route
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  )
}

function Shell() {
  const route = useHashRoute()
  const { user } = useStore()

  let Page = routes[route] || Inicio
  // Invitado en una página privada -> pantalla de inicio de sesión
  if (!user && privateRoutes.includes(route)) Page = Login
  // Con sesión iniciada no tiene sentido ver login ni registro
  if (user && (route === "/login" || route === "/registro")) Page = Inicio

  return (
    <>
      <Navbar />

      {/* Page Container */}
      <div className="w3-container w3-content" style={{ maxWidth: "1400px", marginTop: "80px" }}>
        {/* The Grid */}
        <div className="w3-row">
          {/* Left Column */}
          <div className="w3-col m3">
            <LeftSidebar />
          </div>

          {/* Middle Column (cambia según la ruta) */}
          <div className="w3-col m7">
            <Page />
          </div>

          {/* Right Column */}
          <div className="w3-col m2">
            <RightSidebar />
          </div>
        </div>
      </div>
      <br />

      <Footer />
    </>
  )
}
