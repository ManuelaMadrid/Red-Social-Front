import React, { useState } from 'react'
import { useStore } from '../store'

export default function RightSidebar() {
  const { user, requestStatus, answerRequest } = useStore()
  const [showInfo, setShowInfo] = useState(false)

  return (
    <>
      <div className="w3-card w3-round w3-white w3-center">
        <div className="w3-container">
          <p>Upcoming Events:</p>
          <img src="https://www.w3schools.com/w3images/forest.jpg" alt="Forest" style={{ width: '100%' }} />
          <p><strong>Holiday</strong></p>
          <p>Friday 15:00</p>
          <p><button className="w3-button w3-block w3-theme-l4" onClick={() => setShowInfo(!showInfo)}>Info</button></p>
          {showInfo && <p>Reunión de vacaciones con amigos. Viernes a las 15:00.</p>}
        </div>
      </div>
      <br />

      {user && requestStatus !== 'declined' && (
        <>
      <div className="w3-card w3-round w3-white w3-center">
        <div className="w3-container">
          <p>Friend Request</p>
          <img src="https://www.w3schools.com/w3images/avatar6.png" alt="Avatar" style={{ width: '50%' }} /><br />
          <span>Jane Doe</span>
          {requestStatus === 'accepted' ? (
            <p className="w3-text-green">Ahora son amigos. Escríbele en Messages.</p>
          ) : (
          <div className="w3-row w3-opacity">
            <div className="w3-half">
              <button className="w3-button w3-block w3-green w3-section" title="Accept" onClick={() => answerRequest(true)}><i className="fa fa-check"></i></button>
            </div>
            <div className="w3-half">
              <button className="w3-button w3-block w3-red w3-section" title="Decline" onClick={() => answerRequest(false)}><i className="fa fa-remove"></i></button>
            </div>
          </div>
          )}
        </div>
      </div>
      <br />

        </>
      )}

      <div className="w3-card w3-round w3-white w3-padding-16 w3-center">
        <p>ADS</p>
      </div>
      <br />

      <div className="w3-card w3-round w3-white w3-padding-32 w3-center">
        <p><i className="fa fa-bug w3-xxlarge"></i></p>
      </div>
    </>
  )
}
