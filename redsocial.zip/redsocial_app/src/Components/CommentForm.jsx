import { useState } from 'react'

// Formulario para escribir un comentario (viene de la plantilla)
export default function CommentForm({ getCommentData }) {
  const [comment, setComment] = useState('')

  function getComment(e) {
    setComment(e.target.value)
  }

  function sendComment() {
    // No dejamos publicar comentarios vacíos
    if (comment.trim() === '') return
    getCommentData(comment)
    setComment('') // limpiamos la caja después de comentar
  }

  return (
    <div className="w3-container w3-padding">
      <textarea
        className="w3-input w3-border"
        placeholder="Comenta algo..."
        value={comment}
        onChange={getComment}
      ></textarea>
      <br />
      <button type="button" className="w3-button w3-theme" onClick={sendComment}>
        <i className="fa fa-comment"></i> Comentar
      </button>
    </div>
  )
}
