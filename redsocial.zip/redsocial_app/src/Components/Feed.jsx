import { useRef } from 'react'
import Post from './Post'
import { useStore } from '../store'

const DEFAULT_STATUS = 'Status: Feeling Blue'

export default function Feed() {
  // Los datos de los posts viven en el store compartido
  const { posts, addPost, user } = useStore()
  const box = useRef(null)

  // Al hacer clic en la caja, quitamos el texto de ejemplo para escribir directo
  function clearDefault() {
    if (box.current.textContent.trim() === DEFAULT_STATUS) box.current.textContent = ''
  }

  function publish() {
    const text = box.current.innerText.trim()
    // No dejamos publicar vacío ni el texto de ejemplo
    if (text === '' || text === DEFAULT_STATUS) return
    addPost(text)
    box.current.textContent = DEFAULT_STATUS
  }

  return (
    <>
      <div className="w3-row-padding">
        <div className="w3-col m12">
          <div className="w3-card w3-round w3-white">
            <div className="w3-container w3-padding">
              <h6 className="w3-opacity">Social Media template by w3.css</h6>
              {user ? (
                <>
                  <p
                    ref={box}
                    contentEditable="true"
                    suppressContentEditableWarning
                    className="w3-border w3-padding"
                    onFocus={clearDefault}
                  >
                    {DEFAULT_STATUS}
                  </p>
                  <button type="button" className="w3-button w3-theme" onClick={publish}><i className="fa fa-pencil"></i> Post</button>
                </>
              ) : (
                <p>
                  Estás navegando sin cuenta. <a href="#/login">Inicia sesión</a> o <a href="#/registro">crea una cuenta</a> para publicar.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Publicaciones del muro (dinámicas) */}
      {posts.map((post) => (
        <Post data={post} key={post.id} />
      ))}
    </>
  )
}
