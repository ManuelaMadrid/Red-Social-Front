// Lista de comentarios de una publicación (viene de la plantilla)
export default function ListComments({ listComData }) {
  return (
    <ul className="w3-ul w3-border-top">
      {listComData.map((item) => (
        <li key={item.id}>{item.text}</li>
      ))}
    </ul>
  )
}
