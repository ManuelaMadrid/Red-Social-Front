import { useState } from 'react'
import { useStore } from '../store'

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

// Si el usuario venía de #/login o #/registro, lo llevamos al inicio al entrar
function goHomeIfOnAuthPage() {
  if (['#/login', '#/registro'].includes(window.location.hash)) window.location.hash = '#/'
}

function Field({ label, type = 'text', value, onChange }) {
  return (
    <p>
      <label>{label}</label>
      <input className="w3-input w3-border" type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </p>
  )
}

export function Login() {
  const { login } = useStore()
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')

  function submit(e) {
    e.preventDefault()
    const err = login(form.email, form.password)
    if (err) return setError(err)
    goHomeIfOnAuthPage()
  }

  return (
    <form onSubmit={submit} className="w3-container w3-card w3-white w3-round w3-margin w3-padding">
      <h4>Iniciar sesión</h4>
      <p className="w3-opacity">Inicia sesión para dar like, comentar, publicar y usar los mensajes.</p>
      <hr />
      <Field label="Correo" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
      <Field label="Contraseña" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
      {error && <p className="w3-text-red">{error}</p>}
      <button type="submit" className="w3-button w3-theme"><i className="fa fa-sign-in"></i> Entrar</button>
      <p>¿No tienes cuenta? <a href="#/registro">Crear cuenta</a></p>
    </form>
  )
}

export function Registro() {
  const { register } = useStore()
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [error, setError] = useState('')

  function submit(e) {
    e.preventDefault()
    if (form.name.trim() === '') return setError('Escribe tu nombre.')
    if (!EMAIL.test(form.email.trim())) return setError('Escribe un correo válido.')
    if (form.password.length < 6) return setError('La contraseña debe tener al menos 6 caracteres.')
    if (form.password !== form.confirm) return setError('Las contraseñas no coinciden.')
    const err = register(form)
    if (err) return setError(err)
    goHomeIfOnAuthPage()
  }

  const set = (field) => (v) => setForm({ ...form, [field]: v })

  return (
    <form onSubmit={submit} className="w3-container w3-card w3-white w3-round w3-margin w3-padding">
      <h4>Crear cuenta</h4>
      <hr />
      <Field label="Nombre" value={form.name} onChange={set('name')} />
      <Field label="Correo" type="email" value={form.email} onChange={set('email')} />
      <Field label="Contraseña" type="password" value={form.password} onChange={set('password')} />
      <Field label="Confirmar contraseña" type="password" value={form.confirm} onChange={set('confirm')} />
      {error && <p className="w3-text-red">{error}</p>}
      <button type="submit" className="w3-button w3-theme"><i className="fa fa-user"></i> Crear cuenta</button>
      <p>¿Ya tienes cuenta? <a href="#/login">Iniciar sesión</a></p>
    </form>
  )
}
