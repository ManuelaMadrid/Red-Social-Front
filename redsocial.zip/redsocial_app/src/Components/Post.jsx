import { useState } from 'react'
import CommentForm from './CommentForm'
import ListComments from './ListComments'
import { useStore } from '../store'

export default function Post({ data }) {
  // likes y comentarios viven en el store para que no se pierdan al cambiar de página
  const { user, likePost, addComment } = useStore()

  // Sin sesión no se puede interactuar: se manda al inicio de sesión
  function goLogin() {
    window.location.hash = '#/login'
  }

  // manejo del botón de comentarios (mostrar / ocultar el formulario)
  const [showComments, setShowComments] = useState(false)
  function isShowComment() {
    if (!user) return goLogin()
    setShowComments(!showComments)
  }

  const listData = data.comments || []

  // función que recibe el comentario del formulario y lo agrega a la lista
  function getCommentData(comment) {
    addComment(data.id, comment)
  }

  return (
    <div className="w3-container w3-card w3-white w3-round w3-margin">
      <br />
      <img src={data.avatar} alt="Avatar" className="w3-left w3-circle w3-margin-right" style={{ width: '60px' }} />
      <span className="w3-right w3-opacity">{data.time}</span>
      <h4>{data.name}</h4>
      <br />
      <hr className="w3-clear" />

      {data.beforeText && <p>{data.beforeText}</p>}

      {data.images && data.images.length === 1 && (
        <img src={data.images[0]} style={{ width: '100%' }} className="w3-margin-bottom" alt={data.name} />
      )}

      {data.images && data.images.length === 2 && (
        <div className="w3-row-padding" style={{ margin: '0 -16px' }}>
          <div className="w3-half">
            <img src={data.images[0]} style={{ width: '100%' }} alt="" className="w3-margin-bottom" />
          </div>
          <div className="w3-half">
            <img src={data.images[1]} style={{ width: '100%' }} alt="" className="w3-margin-bottom" />
          </div>
        </div>
      )}

      <p style={{ whiteSpace: 'pre-wrap' }}>{data.text}</p>

      {/* contadores de likes y comentarios */}
      <p className="w3-opacity">
        <span>👍 {data.likes}</span>
        <span className="w3-right">{listData.length} 💬</span>
      </p>

      <button type="button" className="w3-button w3-theme-d1 w3-margin-bottom" onClick={() => (user ? likePost(data.id) : goLogin())}>
        <i className="fa fa-thumbs-up"></i> Like
      </button>{' '}
      <button type="button" className="w3-button w3-theme-d2 w3-margin-bottom" onClick={isShowComment}>
        <i className="fa fa-comment"></i> Comment
      </button>

      {showComments && <CommentForm getCommentData={getCommentData} />}
      <ListComments listComData={listData} />
    </div>
  )
}
