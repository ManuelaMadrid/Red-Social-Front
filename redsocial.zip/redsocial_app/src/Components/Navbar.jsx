import React, { useState } from 'react'
import { useStore } from '../store'

export default function Navbar() {
  // Reemplaza la función openNav() original (manipulaba el DOM a mano)
  const [navOpen, setNavOpen] = useState(false)
  const { user, logout } = useStore()

  function exit() {
    logout()
    setNavOpen(false)
    window.location.hash = '#/'
  }

  return (
    <>
      {/* Navbar */}
      <div className="w3-top">
        <div className="w3-bar w3-theme-d2 w3-left-align w3-large">
          <a
            className="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2"
            href="javascript:void(0);"
            onClick={() => setNavOpen(!navOpen)}
          >
            <i className="fa fa-bars"></i>
          </a>
          <a href="#/" className="w3-bar-item w3-button w3-padding-large w3-theme-d4">
            <i className="fa fa-home w3-margin-right"></i>Logo
          </a>
          <a href="#/noticias" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="News">
            <i className="fa fa-globe"></i>
          </a>
          <a href="#/cuenta" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings">
            <i className="fa fa-user"></i>
          </a>
          <a href="#/mensajes" className="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Messages">
            <i className="fa fa-envelope"></i>
          </a>
          {user && (
            <div className="w3-dropdown-hover w3-hide-small">
              <button className="w3-button w3-padding-large" title="Notifications">
                <i className="fa fa-bell"></i>
                <span className="w3-badge w3-right w3-small w3-green">3</span>
              </button>
              <div className="w3-dropdown-content w3-card-4 w3-bar-block" style={{ width: '300px' }}>
                <a href="#/" className="w3-bar-item w3-button">One new friend request</a>
                <a href="#/perfil" className="w3-bar-item w3-button">John Doe posted on your wall</a>
                <a href="#/perfil" className="w3-bar-item w3-button">Jane likes your post</a>
              </div>
            </div>
          )}
          {user ? (
            <>
              <a href="#/perfil" className="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
                <img src={user.avatar} className="w3-circle" style={{ height: '23px', width: '23px' }} alt="Avatar" />
              </a>
              <a href="#/" onClick={exit} className="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="Cerrar sesión">
                <i className="fa fa-sign-out"></i>
              </a>
            </>
          ) : (
            <>
              <a href="#/registro" className="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white">Crear cuenta</a>
              <a href="#/login" className="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white">Iniciar sesión</a>
            </>
          )}
        </div>
      </div>

      {/* Navbar on small screens */}
      <div id="navDemo" className={`w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large${navOpen ? ' w3-show' : ''}`}>
        <a href="#/noticias" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">Noticias</a>
        {user ? (
          <>
            <a href="#/cuenta" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">Cuenta</a>
            <a href="#/mensajes" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">Mensajes</a>
            <a href="#/perfil" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">My Profile</a>
            <a href="#/" onClick={exit} className="w3-bar-item w3-button w3-padding-large">Cerrar sesión</a>
          </>
        ) : (
          <>
            <a href="#/login" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">Iniciar sesión</a>
            <a href="#/registro" onClick={() => setNavOpen(false)} className="w3-bar-item w3-button w3-padding-large">Crear cuenta</a>
          </>
        )}
      </div>
    </>
  )
}
