import { useState } from 'react'
import { useStore } from '../store'
import Post from './Post'
import Feed from './Feed'

// Cada página reemplaza solo la columna central; los laterales se mantienen.

export function Inicio() {
  return <Feed />
}

const news = [
  { title: 'Nueva función de grupos', text: 'Pronto podrás crear grupos y compartir publicaciones solo con tus miembros.' },
  { title: 'Eventos cerca de ti', text: 'Revisa los eventos del fin de semana y confirma tu asistencia desde tu perfil.' },
  { title: 'Consejos para tus fotos', text: 'Una buena luz natural y un encuadre limpio hacen que tus publicaciones destaquen.' },
]

export function Noticias() {
  return (
    <>
      {news.map((n) => (
        <div key={n.title} className="w3-container w3-card w3-white w3-round w3-margin">
          <br />
          <h4><i className="fa fa-globe w3-margin-right"></i>{n.title}</h4>
          <hr className="w3-clear" />
          <p>{n.text}</p>
        </div>
      ))}
    </>
  )
}

export function Perfil() {
  const { profile, posts, user } = useStore()
  const mine = posts.filter((p) => p.authorId === user.id)
  return (
    <>
      <div className="w3-container w3-card w3-white w3-round w3-margin w3-center">
        <h4>{profile.name}</h4>
        <p><img src={profile.avatar} className="w3-circle" style={{ height: '106px', width: '106px' }} alt="Avatar" /></p>
        <p><i className="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i>{profile.job}</p>
        <p><i className="fa fa-home fa-fw w3-margin-right w3-text-theme"></i>{profile.city}</p>
        <p><i className="fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme"></i>{profile.birthday}</p>
      </div>
      {mine.length === 0 && (
        <div className="w3-container w3-card w3-white w3-round w3-margin w3-padding">
          <p>Aún no has publicado nada. <a href="#/">Ve al inicio para escribir tu primera publicación.</a></p>
        </div>
      )}
      {mine.map((p) => <Post data={p} key={p.id} />)}
    </>
  )
}

export function Cuenta() {
  const { profile, updateProfile } = useStore()
  const [form, setForm] = useState({ name: profile.name, job: profile.job, city: profile.city, birthday: profile.birthday })
  const [saved, setSaved] = useState(false)

  function change(field, value) {
    setForm({ ...form, [field]: value })
    setSaved(false)
  }

  function save() {
    if (form.name.trim() === '') return
    updateProfile(form)
    setSaved(true)
  }

  const fields = [
    ['name', 'Nombre'],
    ['job', 'Profesión'],
    ['city', 'Ciudad'],
    ['birthday', 'Cumpleaños'],
  ]

  return (
    <div className="w3-container w3-card w3-white w3-round w3-margin w3-padding">
      <h4>Account Settings</h4>
      <hr />
      {fields.map(([field, label]) => (
        <p key={field}>
          <label>{label}</label>
          <input className="w3-input w3-border" value={form[field]} onChange={(e) => change(field, e.target.value)} />
        </p>
      ))}
      <button type="button" className="w3-button w3-theme" onClick={save}>
        <i className="fa fa-check"></i> Guardar cambios
      </button>
      {saved && <p className="w3-text-green">Cambios guardados.</p>}
    </div>
  )
}

export function Mensajes() {
  const { friends, getChat, sendMessage } = useStore()
  const [activeId, setActiveId] = useState(friends[0]?.id)
  const [text, setText] = useState('')
  const friend = friends.find((f) => f.id === activeId)
  const messages = getChat(activeId)

  function send() {
    if (!friend || text.trim() === '') return
    sendMessage(activeId, text.trim())
    setText('')
  }

  return (
    <div className="w3-card w3-white w3-round w3-margin">
      <div className="w3-row">
        <div className="w3-third w3-border-right">
          <h5 className="w3-container">Messages</h5>
          <div className="w3-bar-block">
            {friends.map((f) => (
              <button
                key={f.id}
                type="button"
                className={`w3-bar-item w3-button w3-left-align${f.id === activeId ? ' w3-theme-l4' : ''}`}
                onClick={() => setActiveId(f.id)}
              >
                <img src={f.avatar} className="w3-circle w3-margin-right" style={{ width: '30px' }} alt="" />
                {f.name}
              </button>
            ))}
          </div>
        </div>
        <div className="w3-twothird w3-container w3-padding">
          {friend && <h5>{friend.name}</h5>}
          <div style={{ minHeight: '200px' }}>
            {messages.length === 0 && <p className="w3-opacity">Aún no hay mensajes. Escribe el primero.</p>}
            {messages.map((m) => (
              <p key={m.id} className="w3-right-align">
                <span className="w3-tag w3-round w3-theme-l3">{m.text}</span>
              </p>
            ))}
          </div>
          <input
            className="w3-input w3-border"
            placeholder="Escribe un mensaje..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send()}
          />
          <br />
          <button type="button" className="w3-button w3-theme" onClick={send}>
            <i className="fa fa-envelope"></i> Enviar
          </button>
        </div>
      </div>
    </div>
  )
}
