import { createContext, useContext, useEffect, useState } from 'react'

// Estado compartido de la app (posts, perfil, amigos y chats).
// Se guarda en localStorage para que no se pierda al recargar la página.
const IMG = 'https://www.w3schools.com/w3images/'

// Datos que se asignan a una cuenta nueva (se editan luego en Account Settings)
const defaultProfile = { avatar: IMG + 'avatar3.png', job: 'Sin definir', city: 'Sin definir', birthday: 'Sin definir' }

const initialPosts = [
  {
    id: 1,
    avatar: IMG + 'avatar2.png',
    name: 'John Doe',
    time: '1 min',
    beforeText: null,
    images: [IMG + 'lights.jpg', IMG + 'nature.jpg'],
    likes: 0,
    comments: [
      { id: 1, text: 'Me gusta mucho las fotos' },
      { id: 2, text: 'Pásame la ubicación' },
    ],
    text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  },
  {
    id: 2,
    avatar: IMG + 'avatar5.png',
    name: 'Jane Doe',
    time: '16 min',
    beforeText: null,
    images: [],
    likes: 0,
    comments: [],
    text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  },
  {
    id: 3,
    avatar: IMG + 'avatar6.png',
    name: 'Angie Jane',
    time: '32 min',
    beforeText: 'Have you seen this?',
    images: [IMG + 'nature.jpg'],
    likes: 0,
    comments: [{ id: 1, text: 'Sí, está muy bonito' }],
    text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  },
]

const initialFriends = [
  { id: 'john', name: 'John Doe', avatar: IMG + 'avatar2.png' },
  { id: 'angie', name: 'Angie Jane', avatar: IMG + 'avatar6.png' },
]

function useLocalState(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key)
      return saved ? JSON.parse(saved) : initial
    } catch {
      return initial
    }
  })
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      /* si el navegador bloquea el storage, la app sigue funcionando en memoria */
    }
  }, [key, value])
  return [value, setValue]
}

const StoreContext = createContext(null)
export const useStore = () => useContext(StoreContext)

export function StoreProvider({ children }) {
  const [posts, setPosts] = useLocalState('rs2_posts', initialPosts)
  const [users, setUsers] = useLocalState('rs2_users', [])
  const [sessionId, setSessionId] = useLocalState('rs2_session', null)
  const [chats, setChats] = useLocalState('rs2_chats', {})

  // user === null significa que se navega como invitado (sin iniciar sesión)
  const user = users.find((u) => u.id === sessionId) || null
  const friends = user ? user.friends : []
  const requestStatus = user ? user.request : null

  function updateUser(changes) {
    setUsers((prev) => prev.map((u) => (u.id === sessionId ? { ...u, ...changes } : u)))
  }

  // Devuelven un texto de error, o null si todo salió bien
  function register({ name, email, password }) {
    const mail = email.trim().toLowerCase()
    if (users.some((u) => u.email === mail)) return 'Ya existe una cuenta con ese correo.'
    const id = Date.now()
    setUsers((prev) => [
      ...prev,
      { id, name: name.trim(), email: mail, password, ...defaultProfile, friends: initialFriends, request: 'pending' },
    ])
    setSessionId(id)
    return null
  }

  function login(email, password) {
    const mail = email.trim().toLowerCase()
    const found = users.find((u) => u.email === mail && u.password === password)
    if (!found) return 'Correo o contraseña incorrectos.'
    setSessionId(found.id)
    return null
  }

  function logout() {
    setSessionId(null)
  }

  // Las acciones de abajo solo funcionan con sesión iniciada
  function addPost(text) {
    if (!user) return
    setPosts((prev) => [
      { id: Date.now(), authorId: user.id, avatar: user.avatar, name: user.name, time: 'Ahora', beforeText: null, images: [], likes: 0, comments: [], text },
      ...prev,
    ])
  }

  function likePost(id) {
    if (!user) return
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p)))
  }

  function addComment(id, text) {
    if (!user) return
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, comments: [...p.comments, { id: Date.now(), text }] } : p))
    )
  }

  const chatKey = (friendId) => `${sessionId}:${friendId}`
  const getChat = (friendId) => chats[chatKey(friendId)] || []

  function sendMessage(friendId, text) {
    if (!user) return
    setChats((prev) => ({ ...prev, [chatKey(friendId)]: [...(prev[chatKey(friendId)] || []), { id: Date.now(), text }] }))
  }

  function answerRequest(accept) {
    if (!user) return
    const jane = { id: 'jane', name: 'Jane Doe', avatar: IMG + 'avatar6.png' }
    const addJane = accept && !user.friends.some((f) => f.id === 'jane')
    updateUser({ request: accept ? 'accepted' : 'declined', friends: addJane ? [...user.friends, jane] : user.friends })
  }

  return (
    <StoreContext.Provider
      value={{
        posts, user, profile: user, friends, requestStatus,
        register, login, logout, addPost, likePost, addComment,
        updateProfile: updateUser, getChat, sendMessage, answerRequest,
      }}
    >
      {children}
    </StoreContext.Provider>
  )
}
